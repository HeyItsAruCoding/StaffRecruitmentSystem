
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.File;

public class INGCollege {
    private JFrame frame;
    private ArrayList<StaffHire> staffList;

    public INGCollege() {
        frame = new JFrame("ING College Staff Hiring System");
        frame.setLayout(null);
        frame.setSize(1000, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        staffList = new ArrayList<>();
        loadStaffFromFile(); 

        JLabel title = new JLabel("ING College Staff Hiring");
        title.setBounds(350, 10, 300, 30);
        frame.add(title);

        JLabel lblVacancyNumber = new JLabel("Vacancy No:");
        lblVacancyNumber.setBounds(50, 60, 100, 30);
        frame.add(lblVacancyNumber);

        JTextField tfVacancyNumber = new JTextField();
        tfVacancyNumber.setBounds(160, 60, 120, 30);
        frame.add(tfVacancyNumber);

        JLabel lblDesignation = new JLabel("Designation:");
        lblDesignation.setBounds(50, 100, 100, 30);
        frame.add(lblDesignation);

        JTextField tfDesignation = new JTextField();
        tfDesignation.setBounds(160, 100, 120, 30);
        frame.add(tfDesignation);

        JLabel lblSalary = new JLabel("Salary:");
        lblSalary.setBounds(50, 140, 100, 30);
        frame.add(lblSalary);

        JTextField tfSalary = new JTextField();
        tfSalary.setBounds(160, 140, 120, 30);
        frame.add(tfSalary);

        JLabel lblHours = new JLabel("Working Hours:");
        lblHours.setBounds(50, 180, 100, 30);
        frame.add(lblHours);

        JTextField tfHours = new JTextField();
        tfHours.setBounds(160, 180, 120, 30);
        frame.add(tfHours);

        JLabel lblJobType = new JLabel("Job Type:");
        lblJobType.setBounds(50, 220, 100, 30);
        frame.add(lblJobType);

        JTextField tfJobType = new JTextField("Full Time");
        tfJobType.setEditable(false);
        tfJobType.setBounds(160, 220, 120, 30);
        frame.add(tfJobType);

        JLabel lblStaffName = new JLabel("Staff Name:");
        lblStaffName.setBounds(400, 60, 100, 30);
        frame.add(lblStaffName);

        JTextField tfStaffName = new JTextField();
        tfStaffName.setBounds(510, 60, 120, 30);
        frame.add(tfStaffName);

        JLabel lblJoinDate = new JLabel("Joining Date:");
        lblJoinDate.setBounds(400, 100, 100, 30);
        frame.add(lblJoinDate);

        JTextField tfJoinDate = new JTextField();
        tfJoinDate.setBounds(510, 100, 120, 30);
        frame.add(tfJoinDate);

        JLabel lblQualification = new JLabel("Qualification:");
        lblQualification.setBounds(400, 140, 100, 30);
        frame.add(lblQualification);

        JTextField tfQualification = new JTextField();
        tfQualification.setBounds(510, 140, 120, 30);
        frame.add(tfQualification);

        JLabel lblAppointedBy = new JLabel("Appointed By:");
        lblAppointedBy.setBounds(400, 180, 100, 30);
        frame.add(lblAppointedBy);

        JTextField tfAppointedBy = new JTextField();
        tfAppointedBy.setBounds(510, 180, 120, 30);
        frame.add(tfAppointedBy);

        JButton btnAddFullTime = new JButton("Add Full-Time Vacancy");
        btnAddFullTime.setBounds(50, 270, 230, 30);
        frame.add(btnAddFullTime);
        
JLabel lblPTVacancyNumber = new JLabel("PT Vacancy No:");
lblPTVacancyNumber.setBounds(700, 60, 120, 30);
frame.add(lblPTVacancyNumber);

JTextField tfPTVacancyNumber = new JTextField();
tfPTVacancyNumber.setBounds(820, 60, 120, 30);
frame.add(tfPTVacancyNumber);

JLabel lblPTDesignation = new JLabel("Designation:");
lblPTDesignation.setBounds(700, 100, 120, 30);
frame.add(lblPTDesignation);

JTextField tfPTDesignation = new JTextField();
tfPTDesignation.setBounds(820, 100, 120, 30);
frame.add(tfPTDesignation);

JLabel lblPTWorkingHours = new JLabel("Working Hours:");
lblPTWorkingHours.setBounds(700, 140, 120, 30);
frame.add(lblPTWorkingHours);

JTextField tfPTWorkingHours = new JTextField();
tfPTWorkingHours.setBounds(820, 140, 120, 30);
frame.add(tfPTWorkingHours);

JLabel lblPTWage = new JLabel("Wages/Hour:");
lblPTWage.setBounds(700, 180, 120, 30);
frame.add(lblPTWage);

JTextField tfPTWage = new JTextField();
tfPTWage.setBounds(820, 180, 120, 30);
frame.add(tfPTWage);

JLabel lblPTShift = new JLabel("Shift:");
lblPTShift.setBounds(700, 220, 120, 30);
frame.add(lblPTShift);

JTextField tfPTShift = new JTextField();
tfPTShift.setBounds(820, 220, 120, 30);
frame.add(tfPTShift);

JButton btnAddPartTime = new JButton("Add Part-Time Vacancy");
btnAddPartTime.setBounds(700, 270, 240, 30);
frame.add(btnAddPartTime);

JButton btnTerminatePT = new JButton("Terminate Part-Time Staff");
btnTerminatePT.setBounds(700, 540, 240, 30);
frame.add(btnTerminatePT);

btnTerminatePT.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        try {
            int vacancyNumber = Integer.parseInt(tfPTVacancyNumber.getText());

            boolean found = false;

            for (StaffHire s : staffList) {
                if (s instanceof PartTimeStaffHire && s.getVacancyNumber() == vacancyNumber) {
                    PartTimeStaffHire pt = (PartTimeStaffHire) s;

                    if (!pt.getTerminated()) {
                        pt.terminateStaff();
                        JOptionPane.showMessageDialog(frame, "Part-Time Staff terminated.");
                        saveStaffToFile();
                    } else {
                        JOptionPane.showMessageDialog(frame, "Staff is already terminated.");
                    }

                    found = true;
                    break;
                }
            }

            if (!found) {
                JOptionPane.showMessageDialog(frame, "No matching Part-Time vacancy found.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Enter a valid vacancy number.");
        }
    }
});


btnAddPartTime.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        try {
            int vacancyNumber = Integer.parseInt(tfPTVacancyNumber.getText());
            String designation = tfPTDesignation.getText();
            int workingHour = Integer.parseInt(tfPTWorkingHours.getText());
            int wagesPerHour = Integer.parseInt(tfPTWage.getText());
            String shift = tfPTShift.getText();

            boolean exists = false;
            for (StaffHire s : staffList) {
                if (s.getVacancyNumber() == vacancyNumber) {
                    exists = true;
                    break;
                }
            }

            if (exists) {
                JOptionPane.showMessageDialog(frame, "Vacancy number already exists!");
            } else {
                PartTimeStaffHire newPT = new PartTimeStaffHire(vacancyNumber, designation, "Part Time", workingHour, wagesPerHour, shift);
                staffList.add(newPT);
                JOptionPane.showMessageDialog(frame, "Part-Time Vacancy Added!");
                saveStaffToFile();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Please enter valid numbers.");
        }
    }
});

JLabel lblPTStaffName = new JLabel("PT Staff Name:");
lblPTStaffName.setBounds(700, 320, 120, 30);
frame.add(lblPTStaffName);

JTextField tfPTStaffName = new JTextField();
tfPTStaffName.setBounds(820, 320, 120, 30);
frame.add(tfPTStaffName);

JLabel lblPTJoinDate = new JLabel("Joining Date:");
lblPTJoinDate.setBounds(700, 360, 120, 30);
frame.add(lblPTJoinDate);

JTextField tfPTJoinDate = new JTextField();
tfPTJoinDate.setBounds(820, 360, 120, 30);
frame.add(tfPTJoinDate);

JLabel lblPTQualification = new JLabel("Qualification:");
lblPTQualification.setBounds(700, 400, 120, 30);
frame.add(lblPTQualification);

JTextField tfPTQualification = new JTextField();
tfPTQualification.setBounds(820, 400, 120, 30);
frame.add(tfPTQualification);

JLabel lblPTAppointedBy = new JLabel("Appointed By:");
lblPTAppointedBy.setBounds(700, 440, 120, 30);
frame.add(lblPTAppointedBy);

JTextField tfPTAppointedBy = new JTextField();
tfPTAppointedBy.setBounds(820, 440, 120, 30);
frame.add(tfPTAppointedBy);

JButton btnAppointPT = new JButton("Appoint Part-Time Staff");
btnAppointPT.setBounds(700, 490, 240, 30);
frame.add(btnAppointPT);

btnAppointPT.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        try {
            int vacancyNumber = Integer.parseInt(tfPTVacancyNumber.getText());
            String staffName = tfPTStaffName.getText();
            String joiningDate = tfPTJoinDate.getText();
            String qualification = tfPTQualification.getText();
            String appointedBy = tfPTAppointedBy.getText();

            boolean found = false;

            for (StaffHire s : staffList) {
                if (s instanceof PartTimeStaffHire && s.getVacancyNumber() == vacancyNumber) {
                    PartTimeStaffHire pt = (PartTimeStaffHire) s;

                    if (!pt.getJoined()) {
                        pt.hirePartTimeStaff(staffName, joiningDate, qualification, appointedBy);
                        JOptionPane.showMessageDialog(frame, "Part-Time Staff appointed successfully!");
                        saveStaffToFile();
                    } else {
                        JOptionPane.showMessageDialog(frame, "Staff already appointed for this vacancy.");
                    }

                    found = true;
                    break;
                }
            }

            if (!found) {
                JOptionPane.showMessageDialog(frame, "No matching Part-Time vacancy found.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid vacancy number.");
        }
    }
});


        JButton btnAppointFullTime = new JButton("Appoint Full-Time Staff");
        btnAppointFullTime.setBounds(400, 230, 230, 30);
        frame.add(btnAppointFullTime);

        JButton btnDisplayStaff = new JButton("Display Staff");
        btnDisplayStaff.setBounds(50, 320, 230, 30);
        frame.add(btnDisplayStaff);

        btnAddFullTime.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int vacancyNumber = Integer.parseInt(tfVacancyNumber.getText());
                    String designation = tfDesignation.getText();
                    int salary = Integer.parseInt(tfSalary.getText());
                    int workingHour = Integer.parseInt(tfHours.getText());
                    String jobType = tfJobType.getText();

                    boolean exists = false;
                    for (StaffHire s : staffList) {
                        if (s.getVacancyNumber() == vacancyNumber) {
                            exists = true;
                            break;
                        }
                    }

                    if (exists) {
                        JOptionPane.showMessageDialog(frame, "Vacancy number already exists!");
                    } else {
                        FullTimeStaffHire newStaff = new FullTimeStaffHire(vacancyNumber, designation, jobType, salary, workingHour);
                        staffList.add(newStaff);
                        JOptionPane.showMessageDialog(frame, "Full-Time Vacancy Added!");
                        saveStaffToFile();
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter valid numbers.");
                }
            }
        });

        btnAppointFullTime.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int vacancyNumber = Integer.parseInt(tfVacancyNumber.getText());
                    String staffName = tfStaffName.getText();
                    String joiningDate = tfJoinDate.getText();
                    String qualification = tfQualification.getText();
                    String appointedBy = tfAppointedBy.getText();

                    boolean found = false;

                    for (StaffHire s : staffList) {
                        if (s instanceof FullTimeStaffHire && s.getVacancyNumber() == vacancyNumber) {
                            FullTimeStaffHire ft = (FullTimeStaffHire) s;

                            if (!ft.getJoined()) {
                                ft.hireFullTimeStaff(staffName, joiningDate, qualification, appointedBy);
                                JOptionPane.showMessageDialog(frame, "Staff appointed successfully!");
                                saveStaffToFile();
                            } else {
                                JOptionPane.showMessageDialog(frame, "Staff already appointed.");
                            }

                            found = true;
                            break;
                        }
                    }

                    if (!found) {
                        JOptionPane.showMessageDialog(frame, "No matching Full-Time vacancy found.");
                    }

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid vacancy number.");
                }
            }
        });

        btnDisplayStaff.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (staffList.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "No staff records available.");
                    return;
                }

                JTextArea textArea = new JTextArea(15, 50);
                textArea.setEditable(false);

                for (StaffHire s : staffList) {
                    if (s instanceof FullTimeStaffHire) {
                        textArea.append(((FullTimeStaffHire) s).getDisplayText() + "\n");
                    } else if (s instanceof PartTimeStaffHire) {
                        textArea.append(((PartTimeStaffHire) s).getDisplayText() + "\n");
                    }
                }

                JScrollPane scrollPane = new JScrollPane(textArea);
                JOptionPane.showMessageDialog(frame, scrollPane, "All Staff Records", JOptionPane.INFORMATION_MESSAGE);
            }
        });

JButton btnClearAll = new JButton("Clear All Fields");
btnClearAll.setBounds(400, 270, 230, 30);
frame.add(btnClearAll);

btnClearAll.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        
        tfVacancyNumber.setText("");
        tfDesignation.setText("");
        tfSalary.setText("");
        tfHours.setText("");
        tfStaffName.setText("");
        tfJoinDate.setText("");
        tfQualification.setText("");
        tfAppointedBy.setText("");

        
        tfPTVacancyNumber.setText("");
        tfPTDesignation.setText("");
        tfPTWorkingHours.setText("");
        tfPTWage.setText("");
        tfPTShift.setText("");
        tfPTStaffName.setText("");
        tfPTJoinDate.setText("");
        tfPTQualification.setText("");
        tfPTAppointedBy.setText("");
    }
});


        
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new INGCollege();
    }

    private void saveStaffToFile() {
        try {
            FileWriter fw = new FileWriter("staff.txt");
            for (StaffHire s : staffList) {
                fw.write(s.toString() + "\n");
            }
            fw.close();
            System.out.println("Staff data saved.");
        } catch (Exception e) {
            System.out.println("Error saving: " + e.getMessage());
        }
    }

    private void loadStaffFromFile() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("staff.txt"));
            String line;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");

                if (parts[0].equals("FULLTIME")) {
                    int vacancyNumber = Integer.parseInt(parts[1]);
                    String designation = parts[2];
                    String jobType = parts[3];
                    int salary = Integer.parseInt(parts[4]);
                    int workingHour = Integer.parseInt(parts[5]);

                    FullTimeStaffHire ft = new FullTimeStaffHire(vacancyNumber, designation, jobType, salary, workingHour);

                    if (Boolean.parseBoolean(parts[10])) {
                        ft.hireFullTimeStaff(parts[6], parts[7], parts[8], parts[9]);
                    }

                    staffList.add(ft);
                }

                if (parts[0].equals("PARTTIME")) {
                    int vacancyNumber = Integer.parseInt(parts[1]);
                    String designation = parts[2];
                    String jobType = parts[3];
                    int workingHour = Integer.parseInt(parts[4]);
                    int wagesPerHour = Integer.parseInt(parts[5]);
                    String shift = parts[6];

                    PartTimeStaffHire pt = new PartTimeStaffHire(vacancyNumber, designation, jobType, workingHour, wagesPerHour, shift);

                    if (Boolean.parseBoolean(parts[11])) {
                        pt.hirePartTimeStaff(parts[7], parts[8], parts[9], parts[10]);
                    }

                    if (Boolean.parseBoolean(parts[12])) {
                        pt.terminateStaff();
                    }

                    staffList.add(pt);
                }
            }

            br.close();
            System.out.println("Staff loaded.");
        } catch (Exception e) {
            System.out.println("Error loading: " + e.getMessage());
        }
    }
}
