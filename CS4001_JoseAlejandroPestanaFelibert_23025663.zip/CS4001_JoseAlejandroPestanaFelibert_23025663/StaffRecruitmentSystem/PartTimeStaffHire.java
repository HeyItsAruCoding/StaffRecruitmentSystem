public class PartTimeStaffHire extends StaffHire {
    private int workingHour;
    private int wagesPerHour;
    private String shift;
    private String staffName;
    private String joiningDate;
    private String qualification;
    private String appointedBy;
    private boolean joined;
    private boolean terminated;

    public PartTimeStaffHire(int vacancyNumber, String designation, String jobType, int workingHour, int wagesPerHour, String shift) {
        super(vacancyNumber, designation, jobType);
        this.workingHour = workingHour;
        this.wagesPerHour = wagesPerHour;
        this.shift = shift;
        this.staffName = "";
        this.joiningDate = "";
        this.qualification = "";
        this.appointedBy = "";
        this.joined = false;
        this.terminated = false;
    }

    public int getWorkingHour() {
        return workingHour;
    }

    public int getWagesPerHour() {
        return wagesPerHour;
    }

    public String getShift() {
        return shift;
    }

    public String getStaffName() {
        return staffName;
    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public String getQualification() {
        return qualification;
    }

    public String getAppointedBy() {
        return appointedBy;
    }

    public boolean getJoined() {
        return joined;
    }

    public boolean getTerminated() {
        return terminated;
    }

    public void setWorkingHour(int workingHour) {
        this.workingHour = workingHour;
    }

    public void setWagesPerHour(int wagesPerHour) {
        this.wagesPerHour = wagesPerHour;
    }

    public void setShift(String shift) {
        if (!joined) {
            this.shift = shift;
        } else {
            System.out.println("Cannot change shift after staff has joined.");
        }
    }

    public void hirePartTimeStaff(String staffName, String joiningDate, String qualification, String appointedBy) {
        if (!joined) {
            this.staffName = staffName;
            this.joiningDate = joiningDate;
            this.qualification = qualification;
            this.appointedBy = appointedBy;
            this.joined = true;
            this.terminated = false;
        } else {
            System.out.println("Staff already hired.");
        }
    }

    public void terminateStaff() {
        if (terminated) {
            System.out.println("Staff is already terminated.");
        } else {
            this.staffName = "";
            this.joiningDate = "";
            this.qualification = "";
            this.appointedBy = "";
            this.joined = false;
            this.terminated = true;
        }
    }

    public void display() {
        System.out.println("Vacancy Number: " + getVacancyNumber());
        System.out.println("Designation: " + getDesignation());
        System.out.println("Job Type: " + getJobType());
        System.out.println("Wages Per Hour: " + wagesPerHour);
        System.out.println("Working Hours: " + workingHour);
        System.out.println("Shift: " + shift);
        
        if (joined) {
            System.out.println("Staff Name: " + staffName);
            System.out.println("Joining Date: " + joiningDate);
            System.out.println("Qualification: " + qualification);
            System.out.println("Appointed By: " + appointedBy);
        }
    }
    
    @Override
public String toString() {
    return "PARTTIME" + ";" +
           getVacancyNumber() + ";" +
           getDesignation() + ";" +
           getJobType() + ";" +
           workingHour + ";" +
           wagesPerHour + ";" +
           shift + ";" +
           (joined ? staffName : "null") + ";" +
           (joined ? joiningDate : "null") + ";" +
           (joined ? qualification : "null") + ";" +
           (joined ? appointedBy : "null") + ";" +
           joined + ";" +
           terminated;
}

public String getDisplayText() {
    String info = "[PART-TIME STAFF]\n" +
                  "Vacancy Number: " + getVacancyNumber() + "\n" +
                  "Designation: " + getDesignation() + "\n" +
                  "Job Type: " + getJobType() + "\n" +
                  "Working Hours: " + workingHour + "\n" +
                  "Wages Per Hour: " + wagesPerHour + "\n" +
                  "Shift: " + shift + "\n" +
                  "Terminated: " + terminated + "\n";

    if (joined) {
        info += "Staff Name: " + staffName + "\n" +
                "Joining Date: " + joiningDate + "\n" +
                "Qualification: " + qualification + "\n" +
                "Appointed By: " + appointedBy + "\n";
    } else {
        info += "Staff Not Yet Appointed.\n";
    }

    return info;
}

    
}
