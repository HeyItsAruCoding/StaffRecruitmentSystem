public class FullTimeStaffHire extends StaffHire {
    private int salary;
    private int workingHour;
    private String staffName;
    private String joiningDate;
    private String qualification;
    private String appointedBy;
    private boolean joined;

    public FullTimeStaffHire(int vacancyNumber, String designation, String jobType, int salary, int workingHour) {
        super(vacancyNumber, designation, jobType);
        this.salary = salary;
        this.workingHour = workingHour;
        this.staffName = "";
        this.joiningDate = "";
        this.qualification = "";
        this.appointedBy = "";
        this.joined = false;
    }
    
    public int getSalary() {
        return salary;
    }

    public int getWorkingHour() {
        return workingHour;
    }

    public String getStaffName() {
        return staffName;
    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public String getQualification() {
        return qualification;
    }

    public String getAppointedBy() {
        return appointedBy;
    }

    public boolean getJoined() {
        return joined;
    }

    public void setSalary(int salary) {
        if (!joined) {
            this.salary = salary;
        } else {
            System.out.println("Cannot change salary after staff has joined.");
        }
    }

    public void setWorkingHour(int workingHour) {
        this.workingHour = workingHour;
    }

    public void hireFullTimeStaff(String staffName, String joiningDate, String qualification, String appointedBy) {
        if (!joined) {
            this.staffName = staffName;
            this.joiningDate = joiningDate;
            this.qualification = qualification;
            this.appointedBy = appointedBy;
            this.joined = true;
        } else {
            System.out.println("Staff is already hired.");
        }
    }

    public void display() {
        if (joined) {
            System.out.println("Staff Name: " + staffName);
            System.out.println("Salary: " + salary);
            System.out.println("Working Hours: " + workingHour);
            System.out.println("Joining Date: " + joiningDate);
            System.out.println("Qualification: " + qualification);
            System.out.println("Appointed By: " + appointedBy);
        }
    }
    
    public String toString() {
    return "FULLTIME" + ";" +
           getVacancyNumber() + ";" +
           getDesignation() + ";" +
           getJobType() + ";" +
           salary + ";" +
           workingHour + ";" +
           (joined ? staffName : "null") + ";" +
           (joined ? joiningDate : "null") + ";" +
           (joined ? qualification : "null") + ";" +
           (joined ? appointedBy : "null") + ";" +
           joined;
}

public String getDisplayText() {
    String info = "[FULL-TIME STAFF]\n" +
                  "Vacancy Number: " + getVacancyNumber() + "\n" +
                  "Designation: " + getDesignation() + "\n" +
                  "Job Type: " + getJobType() + "\n" +
                  "Salary: " + salary + "\n" +
                  "Working Hours: " + workingHour + "\n";

    if (joined) {
        info += "Staff Name: " + staffName + "\n" +
                "Joining Date: " + joiningDate + "\n" +
                "Qualification: " + qualification + "\n" +
                "Appointed By: " + appointedBy + "\n";
    } else {
        info += "Staff Not Yet Appointed.\n";
    }

    return info;
}


}
