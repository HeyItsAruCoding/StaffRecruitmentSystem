public abstract class StaffHire {
    private int vacancyNumber;
    private String designation;
    private String jobType;

    public StaffHire(int vacancyNumber, String designation, String jobType) {
        this.vacancyNumber = vacancyNumber;
        this.designation = designation;
        this.jobType = jobType;
    }

    public int getVacancyNumber() {
        return vacancyNumber;
    }

    public String getDesignation() {
        return designation;
    }

    public String getJobType() {
        return jobType;
    }

    public void setVacancyNumber(int vacancyNumber) {
        this.vacancyNumber = vacancyNumber;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public abstract void display();
}
